window.admin.removeSubmitButtonOffsetOn("#images");
//# sourceMappingURL=brand.js.map